window.webserverWarningText = `
The data loading feature requires running the sample from a web server. Please follow these steps: <br><br>

For data loading to work:<br>
<ol>
<li>In the package folder, run "npm install" and then "npm start".</li>
<li>Open <a href="http://localhost:9200">http://localhost:9200</a> in a browser.</li>
</ol>
See "readme.txt" for details.
`
